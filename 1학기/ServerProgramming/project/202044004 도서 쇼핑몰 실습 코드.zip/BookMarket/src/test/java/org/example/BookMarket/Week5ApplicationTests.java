package org.example.BookMarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week5ApplicationTests {

    @Test
    void contextLoads() {
    }

}

package org.example.BookMarket.domain;

public enum Role {
    USER,ADMIN
}

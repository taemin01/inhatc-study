package org.example.week5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week5ApplicationTests {

    @Test
    void contextLoads() {
    }

}

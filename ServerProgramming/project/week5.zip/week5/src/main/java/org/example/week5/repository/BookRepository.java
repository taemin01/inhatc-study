package org.example.week5.repository;

import org.example.week5.domain.BookMarket;

import java.util.List;

public interface BookRepository {
    List<BookMarket> getAllBookMarketList();
}

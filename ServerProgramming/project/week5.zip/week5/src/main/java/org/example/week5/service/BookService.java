package org.example.week5.service;

import org.example.week5.domain.BookMarket;


import java.util.List;


public interface BookService {
    List<BookMarket> getAllBookMarketList();
}
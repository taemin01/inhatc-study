package org.example.shoppingmall_202044004;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingMall202044004Application {

    public static void main(String[] args) {
        SpringApplication.run(ShoppingMall202044004Application.class, args);
    }

}

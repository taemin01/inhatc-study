package org.example.shoppingmall_202044004;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingMall202044004ApplicationTests {

    @Test
    void contextLoads() {
    }

}
